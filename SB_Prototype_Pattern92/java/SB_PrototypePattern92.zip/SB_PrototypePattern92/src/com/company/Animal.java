package com.company;

public interface Animal extends Cloneable {
    public Animal makeCopy();
}
