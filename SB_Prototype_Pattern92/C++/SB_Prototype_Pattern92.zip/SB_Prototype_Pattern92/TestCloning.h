#ifndef TESTCLONING
#define TESTCLONING

#include <string>
#include <vector>
#include <iostream>

class TestCloning
{

	//static void main(std::vector<std::wstring>& args);
	int main();

};


#endif	//#ifndef TESTCLONING
