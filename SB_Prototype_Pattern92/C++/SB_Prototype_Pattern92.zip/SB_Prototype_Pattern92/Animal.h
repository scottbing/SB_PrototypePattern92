#ifndef ANIMAL
#define ANIMAL

class Animal 
{
public:
	virtual Animal* makeCopy() = 0;

};


#endif	//#ifndef ANIMAL
